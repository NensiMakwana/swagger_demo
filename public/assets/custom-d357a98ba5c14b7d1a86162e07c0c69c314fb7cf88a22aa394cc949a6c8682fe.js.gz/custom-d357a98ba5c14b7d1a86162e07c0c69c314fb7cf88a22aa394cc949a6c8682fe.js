$("#logo").replaceWith("<span id=\"test\">test</span>");
